Please visit https://lunarclient.com/third-party-mods for more information regarding Lunar Client's
usage of third-party modifications, compliance with licenses, and how to access source code of these mods.
